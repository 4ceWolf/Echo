"""GStreamer playback engine: playback control + spectrum analysis for visualizer."""
import gi
gi.require_version("Gst", "1.0")
from gi.repository import Gst, GObject, GLib
import random

Gst.init(None)

REPEAT_OFF = "off"
REPEAT_ONE = "one"
REPEAT_ALL = "all"


class Player(GObject.Object):
    __gsignals__ = {
        "state-changed": (GObject.SignalFlags.RUN_FIRST, None, (str,)),
        "position-changed": (GObject.SignalFlags.RUN_FIRST, None, (int, int)),  # pos_ms, dur_ms
        "spectrum": (GObject.SignalFlags.RUN_FIRST, None, (object,)),  # list[float] magnitudes
        "track-finished": (GObject.SignalFlags.RUN_FIRST, None, ()),
        "eos": (GObject.SignalFlags.RUN_FIRST, None, ()),
        "track-changed": (GObject.SignalFlags.RUN_FIRST, None, (str,)),  # filepath
        "settings-changed": (GObject.SignalFlags.RUN_FIRST, None, ()),  # shuffle/repeat changed
    }

    def __init__(self):
        super().__init__()
        self.pipeline = Gst.ElementFactory.make("playbin", "player")
        self.spectrum = Gst.ElementFactory.make("spectrum", "spectrum")
        self.spectrum.set_property("bands", 32)
        self.spectrum.set_property("threshold", -70)
        self.spectrum.set_property("post-messages", True)
        self.spectrum.set_property("interval", 50_000_000)  # 50ms in ns

        audio_sink = Gst.ElementFactory.make("bin", "audio_sink_bin")
        convert = Gst.ElementFactory.make("audioconvert", "convert")
        real_sink = Gst.ElementFactory.make("autoaudiosink", "real_sink")

        audio_sink.add(convert)
        audio_sink.add(self.spectrum)
        audio_sink.add(real_sink)
        convert.link(self.spectrum)
        self.spectrum.link(real_sink)

        pad = convert.get_static_pad("sink")
        ghost_pad = Gst.GhostPad.new("sink", pad)
        ghost_pad.set_active(True)
        audio_sink.add_pad(ghost_pad)

        self.pipeline.set_property("audio-sink", audio_sink)

        bus = self.pipeline.get_bus()
        bus.add_signal_watch()
        bus.connect("message", self._on_bus_message)

        self.current_uri = None
        self.current_path = None
        self.duration_ms = 0
        self._position_timeout_id = None

        self.shuffle = False
        self.repeat = REPEAT_OFF
        self.queue: list[str] = []
        self.history: list[int] = []
        self.queue_index = -1

        # Track *intended* playback state ourselves rather than querying
        # GStreamer's pipeline state live. During prerolling/buffering the
        # pipeline briefly reports PAUSED even though we told it to play,
        # which was causing MPRIS consumers (media key panels, Hanabi) to
        # see a stale/incorrect "Paused" until you manually pressed play.
        self._desired_playing = False

    # --- Playback control ---
    def load_and_play(self, filepath: str):
        self._load(filepath, autoplay=True)

    def load_paused(self, filepath: str):
        """Load a track without starting playback (used for restoring last session)."""
        self._load(filepath, autoplay=False)

    def _load(self, filepath: str, autoplay: bool):
        self.pipeline.set_state(Gst.State.NULL)
        self.current_path = filepath
        self.current_uri = Gst.filename_to_uri(filepath)
        self.pipeline.set_property("uri", self.current_uri)
        self.duration_ms = 0
        self._desired_playing = autoplay
        self.pipeline.set_state(Gst.State.PLAYING if autoplay else Gst.State.PAUSED)
        self._ensure_position_timer()
        self.emit("track-changed", filepath)
        self.emit("state-changed", "playing" if autoplay else "paused")

    def play(self):
        if self.current_uri:
            self._desired_playing = True
            self.pipeline.set_state(Gst.State.PLAYING)
            self._ensure_position_timer()
            self.emit("state-changed", "playing")

    def pause(self):
        self._desired_playing = False
        self.pipeline.set_state(Gst.State.PAUSED)
        self.emit("state-changed", "paused")

    def toggle_play_pause(self):
        if self._desired_playing:
            self.pause()
        else:
            self.play()

    def stop(self):
        self._desired_playing = False
        self.pipeline.set_state(Gst.State.NULL)
        self.emit("state-changed", "stopped")

    def seek(self, position_ms: int):
        self.pipeline.seek_simple(
            Gst.Format.TIME, Gst.SeekFlags.FLUSH | Gst.SeekFlags.KEY_UNIT,
            position_ms * Gst.MSECOND
        )

    def set_volume(self, volume: float):
        self.pipeline.set_property("volume", max(0.0, min(1.0, volume)))

    def get_position_ms(self) -> int:
        ok, pos = self.pipeline.query_position(Gst.Format.TIME)
        if ok:
            return pos // Gst.MSECOND
        return 0

    def get_duration_ms(self) -> int:
        ok, dur = self.pipeline.query_duration(Gst.Format.TIME)
        if ok:
            self.duration_ms = dur // Gst.MSECOND
            return self.duration_ms
        return self.duration_ms

    def is_playing(self) -> bool:
        return self._desired_playing

    # --- Queue / library navigation ---
    def set_queue(self, filepaths: list[str], start_index: int = 0):
        self.queue = list(filepaths)
        self.queue_index = start_index
        self.history = []

    def play_at_index(self, index: int):
        if 0 <= index < len(self.queue):
            self.history.append(self.queue_index)
            self.queue_index = index
            self.load_and_play(self.queue[index])

    def next_track(self):
        if not self.queue:
            return
        if self.repeat == REPEAT_ONE:
            self.load_and_play(self.queue[self.queue_index])
            return
        self.history.append(self.queue_index)
        if self.shuffle:
            if len(self.queue) > 1:
                choices = [i for i in range(len(self.queue)) if i != self.queue_index]
                self.queue_index = random.choice(choices)
            self.load_and_play(self.queue[self.queue_index])
            return
        self.queue_index += 1
        if self.queue_index >= len(self.queue):
            if self.repeat == REPEAT_ALL:
                self.queue_index = 0
            else:
                self.queue_index = len(self.queue) - 1
                self.stop()
                return
        self.load_and_play(self.queue[self.queue_index])

    def prev_track(self):
        if not self.queue:
            return
        # if we're more than 3s into the track, restart it instead of going back
        if self.get_position_ms() > 3000:
            self.seek(0)
            return
        if self.shuffle and self.history:
            # go back to what was *actually* played before, not another random pick
            self.queue_index = self.history.pop()
            self.load_and_play(self.queue[self.queue_index])
            return
        self.queue_index -= 1
        if self.queue_index < 0:
            self.queue_index = 0 if self.repeat != REPEAT_ALL else len(self.queue) - 1
        self.load_and_play(self.queue[self.queue_index])

    def set_shuffle(self, enabled: bool):
        self.shuffle = enabled
        self.emit("settings-changed")

    def set_repeat(self, mode: str):
        if mode in (REPEAT_OFF, REPEAT_ONE, REPEAT_ALL):
            self.repeat = mode
            self.emit("settings-changed")

    def cycle_repeat(self) -> str:
        order = [REPEAT_OFF, REPEAT_ALL, REPEAT_ONE]
        self.repeat = order[(order.index(self.repeat) + 1) % len(order)]
        self.emit("settings-changed")
        return self.repeat

    # --- Internal ---
    def _ensure_position_timer(self):
        if self._position_timeout_id is None:
            self._position_timeout_id = GLib.timeout_add(250, self._on_position_tick)

    def _on_position_tick(self):
        if self.current_uri:
            pos = self.get_position_ms()
            dur = self.get_duration_ms()
            self.emit("position-changed", pos, dur)
        return True  # keep going

    def _on_bus_message(self, bus, message):
        t = message.type
        if t == Gst.MessageType.EOS:
            self.emit("eos")
            self.next_track()
        elif t == Gst.MessageType.ERROR:
            err, debug = message.parse_error()
            print(f"[player] GStreamer error: {err} ({debug})")
            self.emit("state-changed", "error")
        elif t == Gst.MessageType.ELEMENT:
            struct = message.get_structure()
            if struct and struct.get_name() == "spectrum":
                magnitudes = struct.get_value("magnitude")
                if magnitudes is not None:
                    self.emit("spectrum", list(magnitudes))
        elif t == Gst.MessageType.ASYNC_DONE:
            # Pipeline finished a state transition (e.g. prerolling after a
            # track load). Re-announce our intended state so MPRIS consumers
            # that queried mid-transition don't stay stuck on a stale value.
            if message.src == self.pipeline:
                self.emit("state-changed", "playing" if self._desired_playing else "paused")
