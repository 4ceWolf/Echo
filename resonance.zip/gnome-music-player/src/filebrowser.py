"""Folder-hierarchy file browser using Gtk.TreeListModel over the filesystem."""
import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, Gio, GObject, GLib, GdkPixbuf, Gdk
from pathlib import Path

from config import SUPPORTED_EXTENSIONS
import art_utils


class FileNode(GObject.Object):
    __gtype_name__ = "FileNode"
    is_playing = GObject.Property(type=bool, default=False)

    def __init__(self, path: Path, is_dir: bool):
        super().__init__()
        self.path = path
        self.is_dir = is_dir
        self.name = path.name or str(path)

    def create_children_model(self, node_cache: dict):
        store = Gio.ListStore(item_type=FileNode)
        try:
            entries = sorted(
                self.path.iterdir(),
                key=lambda p: (not p.is_dir(), p.name.lower()),
            )
        except (PermissionError, FileNotFoundError):
            return store
        for entry in entries:
            if entry.is_dir():
                node = FileNode(entry, True)
                store.append(node)
                node_cache[str(entry)] = node
            elif entry.suffix.lower() in SUPPORTED_EXTENSIONS:
                node = FileNode(entry, False)
                store.append(node)
                node_cache[str(entry)] = node
        return store


class FileBrowser(Gtk.ScrolledWindow):
    __gsignals__ = {
        "track-activated": (GObject.SignalFlags.RUN_FIRST, None, (str,)),
        "folder-activated": (GObject.SignalFlags.RUN_FIRST, None, (object,)),  # list[str] of tracks in folder
    }

    def __init__(self, root_path: str):
        super().__init__()
        self.root_path = Path(root_path)
        self.set_vexpand(True)
        self.set_hexpand(True)

        # Maps absolute path string -> FileNode, for the nodes that have been
        # materialized so far (i.e. their parent folder was expanded at least
        # once). Used to highlight the currently-playing track by path even
        # though ListView recycles row widgets as you scroll.
        self._node_cache: dict = {}
        self._playing_path: str = None
        self._folder_cover_cache: dict = {}  # dir path str -> Gdk.Texture or False (resolved, no cover)

        self.root_store = Gio.ListStore(item_type=FileNode)
        root_node = FileNode(self.root_path, True)
        self.root_store.append(root_node)
        self._node_cache[str(self.root_path)] = root_node

        self.tree_model = Gtk.TreeListModel.new(
            self.root_store,
            False,  # passthrough
            False,  # autoexpand
            self._create_child_model,
        )

        self.selection_model = Gtk.SingleSelection(model=self.tree_model)

        factory = Gtk.SignalListItemFactory()
        factory.connect("setup", self._on_factory_setup)
        factory.connect("bind", self._on_factory_bind)
        factory.connect("unbind", self._on_factory_unbind)

        self.list_view = Gtk.ListView(model=self.selection_model, factory=factory)
        self.list_view.connect("activate", self._on_activate)
        self.list_view.add_css_class("navigation-sidebar")

        self.set_child(self.list_view)

    def _create_child_model(self, item: FileNode):
        if item.is_dir:
            model = item.create_children_model(self._node_cache)
            if model.get_n_items() == 0:
                return None
            return model
        return None

    def _on_factory_setup(self, factory, list_item):
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        expander = Gtk.TreeExpander()
        icon = Gtk.Image()
        label = Gtk.Label(xalign=0)
        label.set_ellipsize(3)  # PANGO_ELLIPSIZE_END
        box.append(icon)
        box.append(label)
        expander.set_child(box)
        list_item.set_child(expander)
        list_item._icon = icon
        list_item._label = label
        list_item._notify_handler = None
        list_item._bound_node = None

    def _on_factory_bind(self, factory, list_item):
        row = list_item.get_item()
        node: FileNode = row.get_item()
        expander = list_item.get_child()
        expander.set_list_row(row)
        list_item._bound_node = node
        self._update_row_visual(list_item, node)
        list_item._notify_handler = node.connect(
            "notify::is-playing", lambda n, p: self._update_row_visual(list_item, n)
        )

    def _on_factory_unbind(self, factory, list_item):
        if list_item._notify_handler is not None and list_item._bound_node is not None:
            list_item._bound_node.disconnect(list_item._notify_handler)
        list_item._notify_handler = None
        list_item._bound_node = None

    def _update_row_visual(self, list_item, node: "FileNode"):
        if node.is_dir:
            texture = self._get_folder_cover_texture(node.path)
            if texture is not None:
                list_item._icon.set_from_paintable(texture)
            else:
                list_item._icon.set_from_icon_name("folder-symbolic")
        else:
            list_item._icon.set_from_icon_name(
                "media-playback-start-symbolic" if node.is_playing else "audio-x-generic-symbolic"
            )
        list_item._label.set_text(node.name)
        if node.is_playing:
            list_item._label.add_css_class("now-playing-track")
        else:
            list_item._label.remove_css_class("now-playing-track")

    def _get_folder_cover_texture(self, dir_path: Path):
        key = str(dir_path)
        cached = self._folder_cover_cache.get(key)
        if cached is not None:
            return cached if cached is not False else None
        cover_path = art_utils.resolve_folder_cover(dir_path)
        if cover_path is None:
            self._folder_cover_cache[key] = False
            return None
        try:
            pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(cover_path, 32, 32, True)
            texture = Gdk.Texture.new_for_pixbuf(pixbuf)
            self._folder_cover_cache[key] = texture
            return texture
        except Exception as e:
            print(f"[filebrowser] failed to load folder cover {cover_path}: {e}")
            self._folder_cover_cache[key] = False
            return None

    def _on_activate(self, list_view, position):
        row = self.selection_model.get_item(position)
        node: FileNode = row.get_item()
        if node.is_dir:
            row.set_expanded(not row.get_expanded())
        else:
            self.emit("track-activated", str(node.path))
            # build queue: all tracks in same directory, in sorted order
            siblings = sorted(
                [p for p in node.path.parent.iterdir()
                 if p.is_file() and p.suffix.lower() in SUPPORTED_EXTENSIONS],
                key=lambda p: p.name.lower(),
            )
            self.emit("folder-activated", [str(p) for p in siblings])

    def set_now_playing(self, filepath: str):
        """Highlight the currently playing track, if its row has been
        materialized (i.e. you've expanded its containing folder at some
        point). Tracks outside any expanded folder simply won't show a
        highlight until you browse to them - there's no cheap way around
        that with a lazy tree without eagerly walking the whole library."""
        if self._playing_path and self._playing_path in self._node_cache:
            self._node_cache[self._playing_path].is_playing = False
        self._playing_path = filepath
        node = self._node_cache.get(filepath)
        if node is not None:
            node.is_playing = True

    def set_root(self, root_path: str):
        self.root_path = Path(root_path)
        self.root_store.remove_all()
        self._node_cache = {}
        self._playing_path = None
        self._folder_cover_cache = {}
        root_node = FileNode(self.root_path, True)
        self.root_store.append(root_node)
        self._node_cache[str(self.root_path)] = root_node

