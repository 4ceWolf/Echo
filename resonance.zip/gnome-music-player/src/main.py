#!/usr/bin/env python3
import sys
import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Gtk, Adw, Gio

from config import APP_ID
from window import ResonanceWindow


class ResonanceApp(Adw.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.FLAGS_NONE)
        self.window = None

    def do_activate(self):
        if not self.window:
            self.window = ResonanceWindow(application=self)
        self.window.present()


def main():
    app = ResonanceApp()
    return app.run(sys.argv)


if __name__ == "__main__":
    sys.exit(main())
