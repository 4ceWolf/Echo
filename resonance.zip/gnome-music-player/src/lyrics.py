"""Parse .lrc lyric files and provide time-synced lookup."""
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

TIME_TAG_RE = re.compile(r"\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]")


@dataclass
class LyricLine:
    time_ms: int
    text: str


class LyricSet:
    def __init__(self, lines: list[LyricLine]):
        self.lines = sorted(lines, key=lambda l: l.time_ms)

    def index_at(self, position_ms: int) -> int:
        """Return index of the active line for a given playback position (-1 if before first)."""
        lo, hi = -1, len(self.lines) - 1
        result = -1
        # simple linear-friendly binary search
        left, right = 0, len(self.lines) - 1
        while left <= right:
            mid = (left + right) // 2
            if self.lines[mid].time_ms <= position_ms:
                result = mid
                left = mid + 1
            else:
                right = mid - 1
        return result

    def __bool__(self):
        return len(self.lines) > 0


def find_lrc_for(audio_path: str) -> Optional[Path]:
    p = Path(audio_path)
    candidate = p.with_suffix(".lrc")
    if candidate.exists():
        return candidate
    return None


def parse_lrc_file(path: Path) -> LyricSet:
    lines: list[LyricLine] = []
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return LyricSet([])

    for raw_line in text.splitlines():
        tags = list(TIME_TAG_RE.finditer(raw_line))
        if not tags:
            continue
        content = TIME_TAG_RE.sub("", raw_line).strip()
        for m in tags:
            minutes = int(m.group(1))
            seconds = int(m.group(2))
            frac = m.group(3) or "0"
            # frac can be 1-3 digits (centiseconds or milliseconds)
            frac_ms = int(frac.ljust(3, "0")[:3]) if len(frac) < 3 else int(frac)
            if len(frac) == 2:
                frac_ms = int(frac) * 10
            elif len(frac) == 1:
                frac_ms = int(frac) * 100
            else:
                frac_ms = int(frac)
            total_ms = minutes * 60_000 + seconds * 1000 + frac_ms
            lines.append(LyricLine(total_ms, content))
    return LyricSet(lines)


def load_lyrics_for(audio_path: str) -> LyricSet:
    lrc = find_lrc_for(audio_path)
    if lrc is None:
        return LyricSet([])
    return parse_lrc_file(lrc)
