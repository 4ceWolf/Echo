"""Bar-style spectrum visualizer rendered via Gtk.DrawingArea + Cairo."""
import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, GLib


class Visualizer(Gtk.DrawingArea):
    def __init__(self):
        super().__init__()
        self.set_vexpand(True)
        self.set_hexpand(True)
        self.set_content_height(60)
        self.set_draw_func(self._draw, None)
        self._magnitudes = []
        self._smoothed = []
        self._decay = 0.75  # smoothing factor for falling bars

        # theming: default purple, optionally overridden by album-art dominant color
        self._base_color = (0.55, 0.45, 0.85)  # the original purple
        self._dynamic_enabled = True
        self._dynamic_color = None  # (r,g,b) 0..1 or None if no art available

    def update_spectrum(self, magnitudes: list):
        # magnitudes come in as dB, typically -70 (silence) to 0 (max)
        normalized = [max(0.0, min(1.0, (m + 70.0) / 70.0)) for m in magnitudes]
        self._apply_normalized(normalized)

    def update_spectrum_normalized(self, values: list):
        # already 0..1 (e.g. from cava), just clamp defensively
        normalized = [max(0.0, min(1.0, v)) for v in values]
        self._apply_normalized(normalized)

    def _apply_normalized(self, normalized: list):
        if not self._smoothed or len(self._smoothed) != len(normalized):
            self._smoothed = normalized[:]
        else:
            for i, v in enumerate(normalized):
                if v > self._smoothed[i]:
                    self._smoothed[i] = v
                else:
                    self._smoothed[i] = self._smoothed[i] * self._decay + v * (1 - self._decay)
        self._magnitudes = normalized
        self.queue_draw()

    def clear(self):
        self._smoothed = [s * 0.6 for s in self._smoothed]
        self.queue_draw()

    def set_dynamic_color(self, rgb):
        """rgb: (r,g,b) each 0..1, or None if no album art available this track."""
        self._dynamic_color = rgb
        self.queue_draw()

    def set_dynamic_enabled(self, enabled: bool):
        self._dynamic_enabled = enabled
        self.queue_draw()

    def _active_color(self):
        if self._dynamic_enabled and self._dynamic_color is not None:
            return self._dynamic_color
        return self._base_color

    def _draw(self, area, cr, width, height, data):
        # Background: transparent, let GTK theme show through
        cr.set_source_rgba(0, 0, 0, 0)
        cr.paint()

        bars = self._smoothed
        if not bars:
            return

        n = len(bars)
        gap = 3
        bar_width = max(2, (width - gap * (n - 1)) / n)

        base_r, base_g, base_b = self._active_color()

        for i, v in enumerate(bars):
            x = i * (bar_width + gap)
            bar_height = max(2, v * (height - 4))
            y = height - bar_height

            # brighten toward the base color as magnitude rises, keep some floor brightness
            r = min(1.0, base_r * (0.6 + 0.4 * v) + 0.15 * v)
            g = min(1.0, base_g * (0.6 + 0.4 * v) + 0.1 * v)
            b = min(1.0, base_b * (0.6 + 0.4 * v))
            cr.set_source_rgba(r, g, b, 0.9)

            # rounded top rectangle
            radius = min(3, bar_width / 2)
            self._rounded_rect(cr, x, y, bar_width, bar_height, radius)
            cr.fill()

    @staticmethod
    def _rounded_rect(cr, x, y, w, h, r):
        cr.new_sub_path()
        cr.arc(x + w - r, y + r, r, -1.5708, 0)
        cr.arc(x + w - r, y + h - r, r, 0, 1.5708)
        cr.arc(x + r, y + h - r, r, 1.5708, 3.14159)
        cr.arc(x + r, y + r, r, 3.14159, 4.71239)
        cr.close_path()
