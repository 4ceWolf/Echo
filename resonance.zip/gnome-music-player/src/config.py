"""App-wide configuration and paths."""
import os
from pathlib import Path

APP_ID = "io.kyo.MusicPlayer"
APP_NAME = "Resonance"

CONFIG_DIR = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "resonance"
CONFIG_FILE = CONFIG_DIR / "config.json"

DEFAULT_MUSIC_DIR = str(Path.home() / "Music")

SUPPORTED_EXTENSIONS = {
    ".mp3", ".flac", ".ogg", ".opus", ".m4a", ".wav", ".wma", ".aac", ".oga",
}

CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def load_config() -> dict:
    import json
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r") as f:
                return json.load(f)
        except Exception:
            pass
    return {
        "library_root": DEFAULT_MUSIC_DIR,
        "shuffle": False,
        "repeat": "off",  # off, one, all
        "volume": 1.0,
        "last_track": None,
    }


def save_config(cfg: dict) -> None:
    import json
    with open(CONFIG_FILE, "w") as f:
        json.dump(cfg, f, indent=2)
