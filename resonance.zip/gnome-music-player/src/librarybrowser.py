"""Flat, searchable view over every track in the library (recursive walk),
as opposed to filebrowser.py's folder-by-folder tree navigation."""
import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, Gio, GObject, GLib
from pathlib import Path
import os

from config import SUPPORTED_EXTENSIONS


class TrackEntry(GObject.Object):
    __gtype_name__ = "TrackEntry"
    is_playing = GObject.Property(type=bool, default=False)

    def __init__(self, path: Path):
        super().__init__()
        self.path = path
        self.display_name = path.stem
        # cheap search key so we're not re-lowering the string on every keystroke
        self.search_key = f"{path.stem} {path.parent.name}".lower()


class LibraryBrowser(Gtk.Box):
    """Search box + flat list of every supported audio file under root_path."""

    __gsignals__ = {
        "track-activated": (GObject.SignalFlags.RUN_FIRST, None, (str,)),
        "folder-activated": (GObject.SignalFlags.RUN_FIRST, None, (object,)),  # list[str], mirrors FileBrowser
    }

    def __init__(self, root_path: str):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.set_vexpand(True)
        self.set_hexpand(True)

        self.root_path = Path(root_path)
        self._node_cache: dict = {}
        self._playing_path: str = None

        self.search_entry = Gtk.SearchEntry(placeholder_text="Search library…")
        self.search_entry.set_margin_top(6)
        self.search_entry.set_margin_bottom(6)
        self.search_entry.set_margin_start(6)
        self.search_entry.set_margin_end(6)
        self.search_entry.connect("search-changed", self._on_search_changed)
        self.append(self.search_entry)

        self.all_store = Gio.ListStore(item_type=TrackEntry)
        self.filter = Gtk.CustomFilter.new(self._filter_func, None)
        self.filter_model = Gtk.FilterListModel.new(self.all_store, self.filter)
        self.selection_model = Gtk.SingleSelection(model=self.filter_model)

        factory = Gtk.SignalListItemFactory()
        factory.connect("setup", self._on_factory_setup)
        factory.connect("bind", self._on_factory_bind)
        factory.connect("unbind", self._on_factory_unbind)

        self.list_view = Gtk.ListView(model=self.selection_model, factory=factory)
        self.list_view.connect("activate", self._on_activate)
        self.list_view.add_css_class("navigation-sidebar")

        scroller = Gtk.ScrolledWindow()
        scroller.set_vexpand(True)
        scroller.set_child(self.list_view)
        self.append(scroller)

        self.status_label = Gtk.Label(label="")
        self.status_label.add_css_class("dim-label")
        self.status_label.add_css_class("caption")
        self.status_label.set_margin_bottom(4)
        self.append(self.status_label)

        self.rescan()

    def rescan(self):
        """Walk the whole library root and rebuild the flat track list."""
        self.all_store.remove_all()
        self._node_cache = {}
        count = 0
        for dirpath, _dirnames, filenames in os.walk(self.root_path):
            for fn in sorted(filenames, key=str.lower):
                p = Path(dirpath) / fn
                if p.suffix.lower() in SUPPORTED_EXTENSIONS:
                    entry = TrackEntry(p)
                    self.all_store.append(entry)
                    self._node_cache[str(p)] = entry
                    count += 1
        self.status_label.set_text(f"{count} tracks")

    def _filter_func(self, item: TrackEntry, user_data):
        query = self.search_entry.get_text().strip().lower()
        if not query:
            return True
        return query in item.search_key

    def _on_search_changed(self, entry):
        self.filter.changed(Gtk.FilterChange.DIFFERENT)

    def _on_factory_setup(self, factory, list_item):
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        box.set_margin_start(12)
        icon = Gtk.Image()
        label_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        title_label = Gtk.Label(xalign=0)
        title_label.set_ellipsize(3)
        folder_label = Gtk.Label(xalign=0)
        folder_label.set_ellipsize(3)
        folder_label.add_css_class("dim-label")
        folder_label.add_css_class("caption")
        label_box.append(title_label)
        label_box.append(folder_label)
        box.append(icon)
        box.append(label_box)
        list_item.set_child(box)
        list_item._icon = icon
        list_item._title_label = title_label
        list_item._folder_label = folder_label
        list_item._notify_handler = None
        list_item._bound_node = None

    def _on_factory_bind(self, factory, list_item):
        entry: TrackEntry = list_item.get_item()
        list_item._bound_node = entry
        self._update_row_visual(list_item, entry)
        list_item._notify_handler = entry.connect(
            "notify::is-playing", lambda n, p: self._update_row_visual(list_item, n)
        )

    def _on_factory_unbind(self, factory, list_item):
        if list_item._notify_handler is not None and list_item._bound_node is not None:
            list_item._bound_node.disconnect(list_item._notify_handler)
        list_item._notify_handler = None
        list_item._bound_node = None

    def _update_row_visual(self, list_item, entry: TrackEntry):
        list_item._icon.set_from_icon_name(
            "media-playback-start-symbolic" if entry.is_playing else "audio-x-generic-symbolic"
        )
        list_item._title_label.set_text(entry.display_name)
        list_item._folder_label.set_text(entry.path.parent.name)
        if entry.is_playing:
            list_item._title_label.add_css_class("now-playing-track")
        else:
            list_item._title_label.remove_css_class("now-playing-track")

    def _on_activate(self, list_view, position):
        entry: TrackEntry = self.selection_model.get_item(position)
        self.emit("track-activated", str(entry.path))
        # queue = the currently *filtered* results, in displayed order
        n = self.filter_model.get_n_items()
        queue = [self.filter_model.get_item(i).path.__str__() for i in range(n)]
        self.emit("folder-activated", queue)

    def set_now_playing(self, filepath: str):
        if self._playing_path and self._playing_path in self._node_cache:
            self._node_cache[self._playing_path].is_playing = False
        self._playing_path = filepath
        node = self._node_cache.get(filepath)
        if node is not None:
            node.is_playing = True

    def set_root(self, root_path: str):
        self.root_path = Path(root_path)
        self.rescan()
