import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Gtk, Adw, GLib, Gio, GObject, GdkPixbuf, Gdk
from pathlib import Path

from filebrowser import FileBrowser
from librarybrowser import LibraryBrowser
from playlistbrowser import PlaylistBrowser
from queueview import QueueView
from visualizer import Visualizer
from player import Player, REPEAT_OFF, REPEAT_ONE, REPEAT_ALL
from mpris import MprisService
from cava_source import CavaSource
import lyrics as lyrics_mod
import art_utils
from config import SUPPORTED_EXTENSIONS
import config as cfg

try:
    from mutagen import File as MutagenFile
except ImportError:
    MutagenFile = None

PURPLE_ACCENT = (0.55, 0.45, 0.85)  # fallback / "off" color, matches visualizer default

# Layered opacity: the album art itself reads as the "main" surface, and
# everything else (controls, panels, switches, sliders) sits a notch behind
# it so there's visible depth instead of one flat translucent slab.
ART_OPACITY = 0.85
UI_OPACITY = 0.68


def ms_to_mmss(ms: int) -> str:
    total_s = int(ms / 1000)
    return f"{total_s // 60}:{total_s % 60:02d}"


class ResonanceWindow(Adw.ApplicationWindow):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.set_default_size(1150, 700)
        self.set_title("Resonance")

        self.cfg = cfg.load_config()
        self.player = Player()
        self.player.connect("position-changed", self._on_position_changed)
        self.player.connect("state-changed", self._on_state_changed)
        self.player.connect("spectrum", self._on_spectrum)
        self.player.connect("eos", self._on_eos)
        self.player.connect("track-changed", self._on_track_changed)
        self.player.connect("settings-changed", self._on_settings_changed)
        self.player.set_shuffle(self.cfg.get("shuffle", False))
        self.player.repeat = self.cfg.get("repeat", REPEAT_OFF)
        self.player.set_volume(self.cfg.get("volume", 1.0))

        self._current_track_path = None
        self._current_lyrics = lyrics_mod.LyricSet([])
        self._seeking = False
        self._lyric_labels = []
        self._lyric_active_index = -1
        self._current_dominant_rgb = None
        self._current_art_pixbuf = None
        self._accent_css_provider = Gtk.CssProvider()

        self._build_ui()

        self.mpris = MprisService("Resonance", self.player, self._get_track_info_for_mpris)
        self.mpris.start()

        # Prefer cava for the visualizer if it's installed - see cava_source.py
        # for why (GStreamer's spectrum element left the top bars always
        # empty for most music). Falls back to the existing GStreamer
        # spectrum data (already wired via player "spectrum" signal) if not.
        self._cava = CavaSource(bars=48, on_data=self._on_cava_data)
        self._cava_active = self._cava.start()

        self._resume_last_track()

        self.connect("close-request", self._on_close)

    # ---------- UI construction ----------
    def _build_ui(self):
        toolbar_view = Adw.ToolbarView()
        header = Adw.HeaderBar()

        choose_folder_btn = Gtk.Button(icon_name="folder-open-symbolic", tooltip_text="Choose music folder")
        choose_folder_btn.connect("clicked", self._on_choose_folder)
        header.pack_start(choose_folder_btn)

        toolbar_view.add_top_bar(header)

        # Main horizontal split: sidebar (browsers) | content (now playing, visualizer, controls)
        split = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        split.set_position(300)
        split.set_hexpand(True)
        split.set_vexpand(True)

        self.file_browser = FileBrowser(self.cfg.get("library_root", cfg.DEFAULT_MUSIC_DIR))
        self.file_browser.connect("track-activated", self._on_track_activated)
        self.file_browser.connect("folder-activated", self._on_folder_activated)

        self.library_browser = LibraryBrowser(self.cfg.get("library_root", cfg.DEFAULT_MUSIC_DIR))
        self.library_browser.connect("track-activated", self._on_track_activated)
        self.library_browser.connect("folder-activated", self._on_folder_activated)

        self.playlist_browser = PlaylistBrowser(self.cfg.get("library_root", cfg.DEFAULT_MUSIC_DIR))
        self.playlist_browser.connect("track-activated", self._on_track_activated)
        self.playlist_browser.connect("folder-activated", self._on_folder_activated)

        self.queue_view = QueueView()
        self.queue_view.connect("jump-to-index", self._on_queue_jump)

        self.browser_stack = Gtk.Stack()
        self.browser_stack.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
        self.browser_stack.add_titled(self.file_browser, "folder", "Folders")
        self.browser_stack.add_titled(self.library_browser, "library", "All Songs")
        self.browser_stack.add_titled(self.playlist_browser, "playlists", "Playlists")
        self.browser_stack.add_titled(self.queue_view, "queue", "Queue")
        self.browser_stack.set_vexpand(True)

        # A plain StackSwitcher clips/hides buttons when there isn't enough
        # width for all of them (that's why "Folders" disappeared before with
        # 3 tabs in a 260px sidebar). Use an explicit, evenly-distributed
        # row of toggle buttons instead so all tabs are always visible.
        switcher_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0, homogeneous=True)
        switcher_box.set_margin_top(6)
        switcher_box.set_margin_bottom(6)
        switcher_box.set_margin_start(6)
        switcher_box.set_margin_end(6)
        tab_defs = [
            ("folder", "folder-symbolic", "Folders"),
            ("library", "system-search-symbolic", "All Songs"),
            ("playlists", "view-list-symbolic", "Playlists"),
            ("queue", "view-continuous-symbolic", "Queue"),
        ]
        self._tab_buttons = {}
        first_btn = None
        for name, icon, tooltip in tab_defs:
            btn = Gtk.ToggleButton()
            btn.set_icon_name(icon)
            btn.set_tooltip_text(tooltip)
            if first_btn is None:
                first_btn = btn
            else:
                btn.set_group(first_btn)
            btn.set_active(name == "folder")
            btn.connect("toggled", self._on_tab_toggled, name)
            switcher_box.append(btn)
            self._tab_buttons[name] = btn

        sidebar_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        sidebar_box.set_name("dynamic-sidebar")
        sidebar_box.set_size_request(300, -1)
        sidebar_box.append(switcher_box)
        sidebar_box.append(self.browser_stack)

        split.set_start_child(sidebar_box)
        split.set_resize_start_child(False)

        content_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        content_box.set_margin_top(12)
        content_box.set_margin_bottom(12)
        content_box.set_margin_start(12)
        content_box.set_margin_end(12)

        # Now playing header: art | title+artist | lyrics (uses the leftover
        # horizontal space instead of a big separate block further down)
        np_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        np_box.set_size_request(-1, 130)

        self.album_art = Gtk.Picture()
        self.album_art.set_content_fit(Gtk.ContentFit.COVER)
        self.album_art_placeholder_icon = Gtk.Image.new_from_icon_name("music-note-symbolic")
        self.album_art_placeholder_icon.set_pixel_size(40)
        self.album_art_placeholder_icon.add_css_class("dim-label")

        art_overlay = Gtk.Overlay()
        art_overlay.set_child(self.album_art)
        art_overlay.add_overlay(self.album_art_placeholder_icon)
        art_frame = Gtk.Frame()
        art_frame.set_name("dynamic-art-frame")
        # explicit size on the frame itself (not just its child) so the
        # space is always reserved even with no art loaded, no paintable,
        # and no natural size to fall back on
        art_frame.set_size_request(130, 130)
        art_frame.set_child(art_overlay)
        np_box.append(art_frame)

        title_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4, valign=Gtk.Align.CENTER)
        title_box.set_size_request(160, -1)
        self.title_label = Gtk.Label(label="No track playing", xalign=0)
        self.title_label.add_css_class("title-2")
        self.title_label.set_wrap(True)
        self.artist_label = Gtk.Label(label="", xalign=0)
        self.artist_label.add_css_class("dim-label")
        title_box.append(self.title_label)
        title_box.append(self.artist_label)
        np_box.append(title_box)

        # Lyrics live here now, filling whatever horizontal space is left.
        # Hidden entirely (not just empty) when the track has no .lrc, so
        # there's no dead placeholder box sitting in the layout.
        lyrics_scroll = Gtk.ScrolledWindow()
        lyrics_scroll.set_name("dynamic-lyrics-scroll")
        lyrics_scroll.set_hexpand(True)
        lyrics_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.lyrics_scroll = lyrics_scroll
        self.lyrics_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.lyrics_box.set_valign(Gtk.Align.CENTER)
        self.lyrics_box.set_margin_top(8)
        self.lyrics_box.set_margin_bottom(8)
        self.lyrics_box.set_margin_start(12)
        self.lyrics_box.set_margin_end(12)
        lyrics_scroll.set_child(self.lyrics_box)
        lyrics_scroll.set_visible(False)
        np_box.append(lyrics_scroll)

        content_box.append(np_box)

        # Visualizer fills all the remaining vertical space between the
        # now-playing header and the transport controls.
        self.visualizer = Visualizer()
        self.visualizer.set_dynamic_enabled(self.cfg.get("dynamic_color", True))
        self.visualizer.set_vexpand(True)
        vis_frame = Gtk.Frame()
        vis_frame.set_name("dynamic-vis-frame")
        vis_frame.set_vexpand(True)
        vis_frame.set_child(self.visualizer)
        content_box.append(vis_frame)

        color_toggle_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6, halign=Gtk.Align.END)
        color_toggle_label = Gtk.Label(label="Match album art")
        color_toggle_label.add_css_class("dim-label")
        color_toggle_label.add_css_class("caption")
        self.dynamic_color_switch = Gtk.Switch()
        self.dynamic_color_switch.add_css_class("dynamic-switch")
        self.dynamic_color_switch.set_active(self.cfg.get("dynamic_color", True))
        self.dynamic_color_switch.connect("state-set", self._on_dynamic_color_toggled)
        color_toggle_box.append(color_toggle_label)
        color_toggle_box.append(self.dynamic_color_switch)

        glass_toggle_label = Gtk.Label(label="Frosted glass theme")
        glass_toggle_label.add_css_class("dim-label")
        glass_toggle_label.add_css_class("caption")
        self.glass_switch = Gtk.Switch()
        self.glass_switch.add_css_class("dynamic-switch")
        self.glass_switch.set_active(self.cfg.get("glass_theme", False))
        self.glass_switch.connect("state-set", self._on_glass_toggled)
        color_toggle_box.append(glass_toggle_label)
        color_toggle_box.append(self.glass_switch)

        content_box.append(color_toggle_box)

        # Seek bar
        seek_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self.pos_label = Gtk.Label(label="0:00")
        self.seek_scale = Gtk.Scale(orientation=Gtk.Orientation.HORIZONTAL)
        self.seek_scale.set_name("dynamic-seek-scale")
        self.seek_scale.set_range(0, 1000)
        self.seek_scale.set_hexpand(True)
        self.seek_scale.set_draw_value(False)
        self.seek_scale.connect("change-value", self._on_seek_change)
        self.dur_label = Gtk.Label(label="0:00")
        seek_box.append(self.pos_label)
        seek_box.append(self.seek_scale)
        seek_box.append(self.dur_label)
        content_box.append(seek_box)

        # Transport controls
        controls_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6, halign=Gtk.Align.CENTER)

        self.shuffle_btn = Gtk.ToggleButton(icon_name="media-playlist-shuffle-symbolic", tooltip_text="Shuffle")
        self.shuffle_btn.set_active(self.player.shuffle)
        self.shuffle_btn.set_name("dynamic-shuffle-btn")
        self.shuffle_btn.connect("toggled", self._on_shuffle_toggled)

        prev_btn = Gtk.Button(icon_name="media-skip-backward-symbolic", tooltip_text="Previous")
        prev_btn.connect("clicked", lambda b: self.player.prev_track())

        self.play_btn = Gtk.Button(icon_name="media-playback-start-symbolic", tooltip_text="Play/Pause")
        self.play_btn.add_css_class("circular")
        self.play_btn.set_name("dynamic-play-btn")
        self.play_btn.connect("clicked", lambda b: self.player.toggle_play_pause())

        next_btn = Gtk.Button(icon_name="media-skip-forward-symbolic", tooltip_text="Next")
        next_btn.connect("clicked", lambda b: self.player.next_track())

        self.repeat_btn = Gtk.Button(icon_name="media-playlist-repeat-symbolic", tooltip_text="Repeat: off")
        self.repeat_btn.set_name("dynamic-repeat-btn")
        self.repeat_btn.connect("clicked", self._on_repeat_clicked)

        for w in (self.shuffle_btn, prev_btn, self.play_btn, next_btn, self.repeat_btn):
            controls_box.append(w)
        content_box.append(controls_box)

        # Volume
        vol_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8, halign=Gtk.Align.CENTER)
        vol_icon = Gtk.Image(icon_name="audio-volume-high-symbolic")
        self.vol_scale = Gtk.Scale(orientation=Gtk.Orientation.HORIZONTAL)
        self.vol_scale.set_name("dynamic-vol-scale")
        self.vol_scale.set_range(0, 100)
        self.vol_scale.set_value(self.cfg.get("volume", 1.0) * 100)
        self.vol_scale.set_size_request(120, -1)
        self.vol_scale.set_draw_value(False)
        self.vol_scale.connect("value-changed", self._on_volume_changed)
        vol_box.append(vol_icon)
        vol_box.append(self.vol_scale)
        content_box.append(vol_box)

        split.set_end_child(content_box)
        split.set_resize_end_child(True)

        toolbar_view.set_content(split)
        self.set_content(toolbar_view)

        self._update_repeat_icon()

        Gtk.StyleContext.add_provider_for_display(
            Gdk.Display.get_default(), self._accent_css_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
        )
        self._refresh_theme()

        # Media key handling via GNOME/GTK: MPRIS covers this at the system level,
        # so no separate keybinding grab is needed here.

    def _on_tab_toggled(self, button, name):
        if button.get_active():
            self.browser_stack.set_visible_child_name(name)

    # ---------- File browser callbacks ----------
    def _on_choose_folder(self, button):
        dialog = Gtk.FileDialog()
        dialog.set_title("Choose music folder")
        dialog.select_folder(self, None, self._on_folder_chosen)

    def _on_folder_chosen(self, dialog, result):
        try:
            folder = dialog.select_folder_finish(result)
        except GLib.Error:
            return
        if folder:
            path = folder.get_path()
            self.cfg["library_root"] = path
            cfg.save_config(self.cfg)
            self.file_browser.set_root(path)
            self.library_browser.set_root(path)
            self.playlist_browser.set_root(path)

    def _on_track_activated(self, browser, filepath):
        self.player.load_and_play(filepath)
        # metadata/lyrics/art are loaded via the track-changed handler below,
        # which fires no matter what triggers a new track (browser click,
        # next/prev buttons, MPRIS Next/Previous, or auto-advance on EOS)

    def _on_folder_activated(self, browser, filepaths):
        if self._current_track_path in filepaths:
            idx = filepaths.index(self._current_track_path)
        else:
            idx = 0
        self.player.set_queue(filepaths, idx)
        self.queue_view.refresh(self.player.queue, self.player.queue_index)

    def _on_queue_jump(self, queue_view, index):
        self.player.play_at_index(index)

    def _resume_last_track(self):
        """Restore the last-played track (paused, not auto-playing) on launch."""
        last_track = self.cfg.get("last_track")
        if not last_track or not Path(last_track).exists():
            return
        try:
            p = Path(last_track)
            siblings = sorted(
                [f for f in p.parent.iterdir()
                 if f.is_file() and f.suffix.lower() in SUPPORTED_EXTENSIONS],
                key=lambda f: f.name.lower(),
            )
            idx = siblings.index(p) if p in siblings else 0
            self.player.set_queue([str(f) for f in siblings], idx)
            self.player.load_paused(last_track)
        except Exception as e:
            print(f"[resume] failed to restore last track: {e}")

    def _on_track_changed(self, player, filepath):
        self._current_track_path = filepath
        self._load_metadata(filepath)
        self._load_lyrics(filepath)
        self.file_browser.set_now_playing(filepath)
        self.library_browser.set_now_playing(filepath)
        if filepath in self.player.queue:
            self.queue_view.set_now_playing_index(self.player.queue.index(filepath))
        # remember for next launch
        self.cfg["last_track"] = filepath
        cfg.save_config(self.cfg)
        # metadata just changed, so tell MPRIS clients (GNOME extension, media keys) immediately
        if getattr(self, "mpris", None):
            self.mpris.notify_properties_changed()

    # ---------- Metadata / album art ----------
    def _load_metadata(self, filepath):
        title = Path(filepath).stem
        artist = ""
        art_pixbuf = None
        art_url = None

        if MutagenFile is not None:
            try:
                audio = MutagenFile(filepath)
                if audio is not None and audio.tags:
                    tags = audio.tags
                    title = self._first_tag(tags, ["TIT2", "title", "\xa9nam"]) or title
                    artist = self._first_tag(tags, ["TPE1", "artist", "\xa9ART"]) or ""
            except Exception as e:
                print(f"[metadata] failed to read tags: {e}")

        art_data = art_utils.extract_embedded_art(filepath)
        if art_data:
            art_pixbuf = art_utils.pixbuf_from_bytes(art_data)
            art_url = art_utils.cache_art_bytes(filepath, art_data)

        self.title_label.set_text(title)
        self.artist_label.set_text(artist)

        if art_pixbuf:
            texture = Gdk.Texture.new_for_pixbuf(art_pixbuf)
            self.album_art.set_paintable(texture)
            self.album_art_placeholder_icon.set_visible(False)
            self._current_dominant_rgb = self._dominant_color(art_pixbuf)
            self._current_art_pixbuf = art_pixbuf
        else:
            self.album_art.set_paintable(None)
            self.album_art_placeholder_icon.set_visible(True)
            self._current_dominant_rgb = None
            self._current_art_pixbuf = None
        self._refresh_theme()

        self._current_metadata = {
            "title": title, "artist": artist, "path": filepath, "art_url": art_url,
        }

    @staticmethod
    def _dominant_color(pixbuf: GdkPixbuf.Pixbuf):
        """Cheap dominant-color estimate: downscale and average pixels, skipping near-black/white."""
        try:
            small = pixbuf.scale_simple(16, 16, GdkPixbuf.InterpType.BILINEAR)
            n_channels = small.get_n_channels()
            pixels = small.get_pixels()
            stride = small.get_rowstride()
            w, h = small.get_width(), small.get_height()
            r_total = g_total = b_total = count = 0
            for y in range(h):
                for x in range(w):
                    offset = y * stride + x * n_channels
                    r, g, b = pixels[offset], pixels[offset + 1], pixels[offset + 2]
                    if (r + g + b) < 60 or (r + g + b) > 720:
                        continue
                    r_total += r
                    g_total += g
                    b_total += b
                    count += 1
            if count == 0:
                return None
            return (r_total / count / 255.0, g_total / count / 255.0, b_total / count / 255.0)
        except Exception as e:
            print(f"[visualizer] dominant color extraction failed: {e}")
            return None

    @staticmethod
    def _first_tag(tags, keys):
        for k in keys:
            try:
                val = tags.get(k)
                if val:
                    if isinstance(val, list):
                        return str(val[0])
                    return str(val)
            except Exception:
                continue
        return None

    # ---------- Lyrics ----------
    def _load_lyrics(self, filepath):
        self._current_lyrics = lyrics_mod.load_lyrics_for(filepath)
        child = self.lyrics_box.get_first_child()
        while child:
            nxt = child.get_next_sibling()
            self.lyrics_box.remove(child)
            child = nxt
        self._lyric_labels = []
        self._lyric_active_index = -1

        if not self._current_lyrics:
            # no .lrc for this track - hide the whole area, no dead placeholder box
            self.lyrics_scroll.set_visible(False)
            return

        self.lyrics_scroll.set_visible(True)
        for line in self._current_lyrics.lines:
            label = Gtk.Label(label=line.text or "♪")
            label.set_wrap(True)
            label.set_xalign(0)
            label.add_css_class("dim-label")
            label.add_css_class("caption")
            self.lyrics_box.append(label)
            self._lyric_labels.append(label)

    def _update_lyric_highlight(self, position_ms):
        if not self._current_lyrics:
            return
        idx = self._current_lyrics.index_at(position_ms)
        if idx == self._lyric_active_index:
            return
        if 0 <= self._lyric_active_index < len(self._lyric_labels):
            self._lyric_labels[self._lyric_active_index].remove_css_class("title-4")
            self._lyric_labels[self._lyric_active_index].add_css_class("dim-label")
        if 0 <= idx < len(self._lyric_labels):
            self._lyric_labels[idx].remove_css_class("dim-label")
            self._lyric_labels[idx].add_css_class("title-4")
            self._scroll_lyrics_to(self._lyric_labels[idx])
        self._lyric_active_index = idx

    def _scroll_lyrics_to(self, label: Gtk.Label):
        """Center the given lyric line in the scroll view."""
        def do_scroll():
            ok, rect = label.compute_bounds(self.lyrics_box)
            if not ok:
                return False
            adj = self.lyrics_scroll.get_vadjustment()
            viewport_height = self.lyrics_scroll.get_allocated_height()
            target = rect.origin.y + rect.size.height / 2 - viewport_height / 2
            target = max(adj.get_lower(), min(target, adj.get_upper() - adj.get_page_size()))
            adj.set_value(target)
            return False
        GLib.idle_add(do_scroll)

    # ---------- Player signal handlers ----------
    def _on_position_changed(self, player, pos_ms, dur_ms):
        if not self._seeking:
            self.pos_label.set_text(ms_to_mmss(pos_ms))
            self.dur_label.set_text(ms_to_mmss(dur_ms))
            if dur_ms > 0:
                self.seek_scale.set_value((pos_ms / dur_ms) * 1000)
        self._update_lyric_highlight(pos_ms)

    def _on_state_changed(self, player, state):
        if state == "playing":
            self.play_btn.set_icon_name("media-playback-pause-symbolic")
        else:
            self.play_btn.set_icon_name("media-playback-start-symbolic")
            if state in ("stopped", "error"):
                self.visualizer.clear()

    def _on_spectrum(self, player, magnitudes):
        # only used as a fallback when cava isn't installed/running
        if not self._cava_active:
            self.visualizer.update_spectrum(magnitudes)

    def _on_cava_data(self, values):
        self.visualizer.update_spectrum_normalized(values)

    def _on_eos(self, player):
        pass  # player.py already advances to next_track via its own EOS handler

    # ---------- UI control handlers ----------
    def _on_seek_change(self, scale, scroll_type, value):
        dur = self.player.get_duration_ms()
        if dur > 0:
            target_ms = int((value / 1000) * dur)
            self.player.seek(target_ms)
            self.mpris.notify_seeked(target_ms)
        return False

    def _on_shuffle_toggled(self, button):
        self.player.set_shuffle(button.get_active())
        self.cfg["shuffle"] = button.get_active()
        cfg.save_config(self.cfg)

    def _on_settings_changed(self, player):
        """Fires on shuffle/repeat change from anywhere, including MPRIS writes
        from GNOME extensions. Sync the GTK controls without re-triggering
        their own change handlers in a loop (set_active/checked no-ops if
        the value is already correct)."""
        if self.shuffle_btn.get_active() != player.shuffle:
            self.shuffle_btn.set_active(player.shuffle)
        self.cfg["shuffle"] = player.shuffle
        self.cfg["repeat"] = player.repeat
        cfg.save_config(self.cfg)
        self._update_repeat_icon()

    def _on_repeat_clicked(self, button):
        self.player.cycle_repeat()
        self.cfg["repeat"] = self.player.repeat
        cfg.save_config(self.cfg)
        self._update_repeat_icon()

    def _update_repeat_icon(self):
        tooltip = {
            REPEAT_OFF: "Repeat: off",
            REPEAT_ALL: "Repeat: all",
            REPEAT_ONE: "Repeat: one",
        }[self.player.repeat]
        self.repeat_btn.set_tooltip_text(tooltip)
        if self.player.repeat == REPEAT_ONE:
            self.repeat_btn.set_icon_name("media-playlist-repeat-song-symbolic")
        else:
            self.repeat_btn.set_icon_name("media-playlist-repeat-symbolic")
        if self.player.repeat == REPEAT_OFF:
            self.repeat_btn.remove_css_class("repeat-active")
        else:
            self.repeat_btn.add_css_class("repeat-active")

    def _on_dynamic_color_toggled(self, switch, state):
        self.visualizer.set_dynamic_enabled(state)
        self.cfg["dynamic_color"] = state
        cfg.save_config(self.cfg)
        self._refresh_theme()
        return False

    def _on_glass_toggled(self, switch, state):
        self.cfg["glass_theme"] = state
        cfg.save_config(self.cfg)
        self._refresh_theme()
        return False

    def _refresh_theme(self):
        """Apply the active accent color (dynamic album-art color, or fixed
        purple) to the visualizer and transport controls, and optionally a
        whole-app frosted-glass look with layered opacity: the album art
        panel reads as the "main" surface (ART_OPACITY), everything else -
        header bar, sidebar, sliders, buttons, switches, panels - sits a
        notch further back (UI_OPACITY) so there's actual depth instead of
        one flat translucent slab.

        The glass background is a radial color wash using the accent color
        (not a blurred photo of the album art) - it "spreads" from roughly
        where the album art sits, fading into a dark neutral, like the
        classic glassmorphism color-wash look. Real desktop blur-behind-
        window (the actual glass part) comes from the companion GNOME Shell
        extension in shell-extension/resonance-blur@kyo - that's a
        compositor-level effect no GTK app can do by itself, which is why
        it's a separate installable piece rather than Python code here.
        """
        dynamic_enabled = self.cfg.get("dynamic_color", True)
        if dynamic_enabled and self._current_dominant_rgb is not None:
            rgb = self._current_dominant_rgb
        else:
            rgb = PURPLE_ACCENT

        self.visualizer.set_dynamic_color(self._current_dominant_rgb if dynamic_enabled else None)

        r, g, b = [int(c * 255) for c in rgb]
        r2, g2, b2 = [min(255, int(c * 255) + 25) for c in rgb]

        glass_enabled = self.cfg.get("glass_theme", False)

        glass_rules = ""
        if glass_enabled:
            glass_rules = f"""
            window {{
                background-image: radial-gradient(circle at 14% 18%,
                    rgba({r},{g},{b},0.55) 0%,
                    rgba({max(0,r-30)},{max(0,g-30)},{max(0,b-30)},0.35) 45%,
                    rgba(18,16,22,0.55) 85%);
            }}
            .background {{
                background-color: transparent;
            }}
            box, scrolledwindow, viewport, frame, paned, list, listview, row {{
                background-color: transparent;
            }}
            headerbar {{
                background-color: rgba({r},{g},{b},{UI_OPACITY * 0.55:.3f});
                background-image: none;
                box-shadow: none;
                border-bottom: 1px solid rgba(255,255,255,0.14);
            }}
            headerbar windowtitle,
            headerbar windowtitle label,
            headerbar .title {{
                text-shadow: 0 1px 3px rgba(0,0,0,0.65);
            }}
            #dynamic-sidebar {{
                background-color: rgba({r},{g},{b},{UI_OPACITY * 0.3:.3f});
                border-right: 1px solid rgba(255,255,255,0.10);
            }}
            #dynamic-art-frame {{
                background-color: rgba({r},{g},{b},{ART_OPACITY * 0.35:.3f});
                border: 1px solid rgba(255,255,255,0.20);
                border-radius: 16px;
            }}
            #dynamic-vis-frame, #dynamic-lyrics-scroll {{
                background-color: rgba({r},{g},{b},{UI_OPACITY * 0.35:.3f});
                border: 1px solid rgba(255,255,255,0.14);
                border-radius: 14px;
            }}
            #dynamic-play-btn {{
                opacity: {min(1.0, UI_OPACITY + 0.2):.2f};
            }}
            #dynamic-shuffle-btn, #dynamic-repeat-btn, switch.dynamic-switch,
            #dynamic-seek-scale, #dynamic-vol-scale {{
                opacity: {min(1.0, UI_OPACITY + 0.15):.2f};
            }}
            paned > separator {{
                background-color: rgba(255,255,255,0.08);
            }}
            filechooser, filechooserwidget {{
                background-color: rgba({r},{g},{b},{UI_OPACITY * 0.3:.3f});
            }}
            """
        else:
            glass_rules = """
            window { background-image: unset; }
            headerbar { background-image: unset; }
            """

        css = f"""
        #dynamic-play-btn {{
            background-color: rgb({r},{g},{b});
            color: white;
        }}
        #dynamic-play-btn:hover {{
            background-color: rgb({r2},{g2},{b2});
        }}
        #dynamic-seek-scale trough highlight,
        #dynamic-vol-scale trough highlight {{
            background-color: rgb({r},{g},{b});
        }}
        #dynamic-seek-scale slider,
        #dynamic-vol-scale slider {{
            background-color: rgb({r},{g},{b});
        }}
        #dynamic-shuffle-btn:checked {{
            background-color: rgb({r},{g},{b});
            color: white;
        }}
        #dynamic-repeat-btn.repeat-active {{
            background-color: rgb({r},{g},{b});
            color: white;
        }}
        switch.dynamic-switch:checked {{
            background-color: rgb({r},{g},{b});
        }}
        .now-playing-track {{
            font-weight: bold;
            color: rgb({r},{g},{b});
        }}
        {glass_rules}
        """
        self._accent_css_provider.load_from_data(css.encode("utf-8"))

    def _on_volume_changed(self, scale):
        vol = scale.get_value() / 100.0
        self.player.set_volume(vol)
        self.cfg["volume"] = vol
        cfg.save_config(self.cfg)

    # ---------- MPRIS support ----------
    def _get_track_info_for_mpris(self):
        if not self._current_track_path:
            return {}
        meta = getattr(self, "_current_metadata", {})
        return {
            "title": meta.get("title", Path(self._current_track_path).stem),
            "artist": meta.get("artist", ""),
            "album": "",
            "length_us": self.player.get_duration_ms() * 1000,
            "art_url": meta.get("art_url"),
        }

    def _on_close(self, *args):
        cfg.save_config(self.cfg)
        if getattr(self, "_cava", None):
            self._cava.stop()
        return False
