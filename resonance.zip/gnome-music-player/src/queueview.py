"""Sidebar tab showing the current play queue, each row with its own
album-art thumbnail (extracted lazily, cached in memory), and the currently
playing track highlighted. Clicking a row jumps directly to that track."""
import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, Gio, GObject, GdkPixbuf, Gdk
from pathlib import Path

import art_utils

_thumb_cache: dict = {}  # path -> Gdk.Texture, process-lifetime cache


class QueueEntry(GObject.Object):
    __gtype_name__ = "QueueEntry"
    is_playing = GObject.Property(type=bool, default=False)

    def __init__(self, path: str, index: int):
        super().__init__()
        self.path = path
        self.index = index
        self.display_name = Path(path).stem


class QueueView(Gtk.Box):
    __gsignals__ = {
        "jump-to-index": (GObject.SignalFlags.RUN_FIRST, None, (int,)),
    }

    def __init__(self):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.set_vexpand(True)
        self.set_hexpand(True)

        self.store = Gio.ListStore(item_type=QueueEntry)
        self.selection_model = Gtk.SingleSelection(model=self.store)

        factory = Gtk.SignalListItemFactory()
        factory.connect("setup", self._on_factory_setup)
        factory.connect("bind", self._on_factory_bind)
        factory.connect("unbind", self._on_factory_unbind)

        self.list_view = Gtk.ListView(model=self.selection_model, factory=factory)
        self.list_view.connect("activate", self._on_activate)
        self.list_view.add_css_class("navigation-sidebar")

        scroller = Gtk.ScrolledWindow()
        scroller.set_vexpand(True)
        scroller.set_child(self.list_view)
        self.append(scroller)

        self.status_label = Gtk.Label(label="Queue is empty")
        self.status_label.add_css_class("dim-label")
        self.status_label.add_css_class("caption")
        self.status_label.set_margin_top(4)
        self.status_label.set_margin_bottom(4)
        self.append(self.status_label)

    def refresh(self, queue: list, current_index: int):
        self.store.remove_all()
        for i, path in enumerate(queue):
            self.store.append(QueueEntry(path, i))
        if not queue:
            self.status_label.set_text("Queue is empty")
        else:
            self.status_label.set_text(f"{len(queue)} tracks in queue")
        self.set_now_playing_index(current_index)

    def set_now_playing_index(self, index: int):
        for i in range(self.store.get_n_items()):
            entry: QueueEntry = self.store.get_item(i)
            entry.is_playing = (i == index)
        if 0 <= index < self.store.get_n_items():
            self.selection_model.set_selected(index)
            # scroll the playing row into view
            self.list_view.scroll_to(index, Gtk.ListScrollFlags.NONE, None)

    def _on_factory_setup(self, factory, list_item):
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        box.set_margin_start(8)
        box.set_margin_top(3)
        box.set_margin_bottom(3)

        cover = Gtk.Picture()
        cover.set_size_request(36, 36)
        cover.set_content_fit(Gtk.ContentFit.COVER)
        cover_frame = Gtk.Frame()
        cover_frame.set_child(cover)
        box.append(cover_frame)

        label = Gtk.Label(xalign=0)
        label.set_ellipsize(3)
        box.append(label)

        list_item.set_child(box)
        list_item._cover = cover
        list_item._label = label
        list_item._notify_handler = None
        list_item._bound_node = None

    def _on_factory_bind(self, factory, list_item):
        entry: QueueEntry = list_item.get_item()
        list_item._bound_node = entry
        self._update_row_visual(list_item, entry)
        list_item._notify_handler = entry.connect(
            "notify::is-playing", lambda n, p: self._update_row_visual(list_item, n)
        )
        self._load_thumbnail(list_item, entry)

    def _on_factory_unbind(self, factory, list_item):
        if list_item._notify_handler is not None and list_item._bound_node is not None:
            list_item._bound_node.disconnect(list_item._notify_handler)
        list_item._notify_handler = None
        list_item._bound_node = None

    def _update_row_visual(self, list_item, entry: QueueEntry):
        list_item._label.set_text(entry.display_name)
        if entry.is_playing:
            list_item._label.add_css_class("now-playing-track")
        else:
            list_item._label.remove_css_class("now-playing-track")

    def _load_thumbnail(self, list_item, entry: QueueEntry):
        cached = _thumb_cache.get(entry.path)
        if cached is not None:
            list_item._cover.set_paintable(cached)
            return
        data = art_utils.extract_embedded_art(entry.path)
        if not data:
            list_item._cover.set_paintable(None)
            return
        pixbuf = art_utils.pixbuf_from_bytes(data)
        if pixbuf is None:
            list_item._cover.set_paintable(None)
            return
        texture = Gdk.Texture.new_for_pixbuf(pixbuf)
        _thumb_cache[entry.path] = texture
        list_item._cover.set_paintable(texture)

    def _on_activate(self, list_view, position):
        entry: QueueEntry = self.selection_model.get_item(position)
        self.emit("jump-to-index", entry.index)
