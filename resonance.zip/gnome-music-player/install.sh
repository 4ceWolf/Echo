#!/usr/bin/env bash
set -e

echo "Stopping any running Resonance instance..."
pkill -f resonance-player 2>/dev/null || true

echo "Installing Resonance dependencies (pacman)..."
sudo pacman -S --needed --noconfirm \
    python \
    python-gobject \
    gtk4 \
    libadwaita \
    gstreamer \
    gst-plugins-base \
    gst-plugins-good \
    gst-plugins-bad \
    gst-plugins-ugly \
    gst-libav \
    python-mutagen \
    python-pillow \
    python-cairo \
    cava

INSTALL_DIR="$HOME/.local/share/resonance"
BIN_DIR="$HOME/.local/bin"
DESKTOP_DIR="$HOME/.local/share/applications"

echo "Removing any previous Resonance install so old cached files can't linger..."
rm -rf "$INSTALL_DIR"

mkdir -p "$INSTALL_DIR" "$BIN_DIR" "$DESKTOP_DIR"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cp -r "$SCRIPT_DIR/src/"* "$INSTALL_DIR/"

cat > "$BIN_DIR/resonance-player" << EOF
#!/usr/bin/env bash
exec python3 "$INSTALL_DIR/main.py" "\$@"
EOF
chmod +x "$BIN_DIR/resonance-player"

cp "$SCRIPT_DIR/data/io.kyo.MusicPlayer.desktop" "$DESKTOP_DIR/"

# GNOME Shell extension that applies real blur-behind-window to Resonance
# specifically (see shell-extension/resonance-blur@kyo/extension.js for
# how/why). Only makes sense on GNOME/Mutter, so this is best-effort.
EXT_UUID="resonance-blur@kyo"
EXT_DEST="$HOME/.local/share/gnome-shell/extensions/$EXT_UUID"
if [ -d "$SCRIPT_DIR/shell-extension/$EXT_UUID" ]; then
    echo "Installing the Resonance Blur GNOME Shell extension..."
    mkdir -p "$HOME/.local/share/gnome-shell/extensions"
    rm -rf "$EXT_DEST"
    cp -r "$SCRIPT_DIR/shell-extension/$EXT_UUID" "$EXT_DEST"
    if command -v gnome-extensions >/dev/null 2>&1; then
        gnome-extensions enable "$EXT_UUID" 2>/dev/null || \
            echo "Couldn't auto-enable it - open the Extensions app and enable 'Resonance Blur' manually."
    else
        echo "gnome-extensions CLI not found - open the Extensions app and enable 'Resonance Blur' manually."
    fi
    echo "Note: on Wayland, GNOME Shell extensions often need a full logout/login (not just app restart) to take effect."
fi

echo ""
echo "Done. Make sure ~/.local/bin is in your PATH (fish: 'set -Ux fish_user_paths \$HOME/.local/bin \$fish_user_paths')."
echo "Launch with: resonance-player"
echo "Or find 'Resonance' in your GNOME app grid (may need a logout/relogin for the desktop entry to show up)."
